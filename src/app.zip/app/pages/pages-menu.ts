import { NbMenuItem } from '@nebular/theme';

export const MENU_ITEMS: NbMenuItem[] = [

  {
    title: 'Dashboard',
    icon: 'pie-chart-outline',
    link: '/pages/dashboard',
  },

  /* {
     title: 'AÇÕES',
     group: true,
   },*/
  {
    title: 'Cadastros',
    icon: 'layout-outline',
    children: [
      {
        title: 'Estados',
        link: '/pages/estado/estado-iud',
      },
      {
        title: 'Ceps',
        link: '/pages/cep/cep-pesquisa',
      },
      {
        title: 'Cidades',
        link: '/pages/cidades/cidade-iud',
      },
      {
        title: 'Distritos',
        link: '/pages/distrito/distrito-iud',
      },
      {
        title: 'Bairros',
        link: '/pages/bairro/bairro-iud',
      },
      {
        title: 'Logradouros',
        link: '/pages/logradouro/logradouro-iud',
      },
      {
        title: 'Países',
        link: '/pages/paises/pais-iud',
      },
      {
        title: 'Pessoas',
        icon: 'people-outline',
        link: '/pages/pessoa/pessoa-pesquisa',
      },
      {
        title: 'Tipos Logradouros',
        link: '/pages/tipo-logradouro/tipo-logradouro-iud',
      },
      {
        title: 'Tipos Pessoas',
        link: '/pages/tipo-pessoa/tipo-pessoa-iud',
      },
      {
        title: 'Modalidades',
        link: '/pages/modalidades/modalidade-pesquisa',
      },
    ],
  },
  {
    title: 'Atividades',
    icon: 'edit-2-outline',
    children: [
      // =================================================================
      // <<< NOVO SUB-MENU DE SEGURANÇA ADICIONADO AQUI
      // =================================================================
      {
        title: 'Unifica Pessoas',
        children: [

          // ===== PESSOAS =====
          {
            title: 'Pessoas',
            icon: 'people-outline',
            children: [
              /*{
                title: 'CPF NO NOME',
                link: '/pages/unificacao/pessoas/cpf-no-nome',
              },*/
              {
                title: 'CPF ÚNICO',
                link: '/pages/unificacao/pessoas/pes-pessoa',
              },
              {
                title: 'CPF DUPLICADO',
                link: '/pages/unificacao/pessoas/cpf-duplicado',
              },
              /*{
                title: 'CNPJ ÚNICO',
                link: '/pages/unificacao/pessoas/cnpj-unico',
              },*/
              /*{
                title: 'CNPJ DUPLICADO',
                link: '/pages/unificacao/pessoas/cnpj-duplicado',
              },*/
            ],
          },

          // ===== RH =====
          {
            title: 'RH',
            icon: 'briefcase-outline',
            children: [
              {
                title: 'Pessoas RH',
                link: '/pages/unificacao/rh',
              },
            ],
          },

          // ===== SANEAMENTO =====
          {
            title: 'SANEAMENTO',
            icon: 'briefcase-outline',
            children: [
              {
                title: 'CPF ÚNICO',
                link: '/pages/unificacao/saneamento',
              },
              {
                title: 'CPF DUPLICADO',
                link: '/pages/unificacao/saneamento/sane-cpf-duplicado',
              },
              /*{
                title: 'CNPJ ÚNICO',
                link: '/pages/unificacao/saneamento/sane-cnpj-unico',
              },*/
            ],
          },

        ],
      },

      {
        title: 'Form Inputs',
        link: '/pages/forms/inputs',
      },
    ],
  },
  {
    title: 'Consultas',
    icon: 'keypad-outline',
    children: [
      {
        title: 'Grid',
        link: '/pages/ui-features/grid',
      },
    ],
  },
  {
    title: 'Relatorios',
    icon: 'browser-outline',
    children: [
      {
        title: 'Dialog',
        link: '/pages/modal-overlays/dialog',
      },
    ],
  },
];
