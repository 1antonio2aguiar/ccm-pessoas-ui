import { Component } from '@angular/core';
import { LocalDataSource } from 'ng2-smart-table';
import { NbDialogService, NbToastrService } from '@nebular/theme';
import { HttpParams } from '@angular/common/http';

import { PesPessoaService } from '../pes-pessoa.service';
import { FiltroPaginado } from '../../../../../shared/filters/filtro-paginado';
import { ConfirmationDialogComponent } from '../../../../components/base-resource-confirmation-delete/confirmation-dialog/confirmation-dialog.component';

@Component({
  selector: 'ngx-pes-pessoa-iud',
  templateUrl: './pes-pessoa-iud.component.html',
  styleUrls: ['./pes-pessoa-iud.component.scss'],
})

export class PesPessoaIudComponent {

  source: LocalDataSource = new LocalDataSource();
  filtro: FiltroPaginado = new FiltroPaginado();

  settings = {
    pager: {
      perPage: this.filtro.itensPorPagina,
      display: true,
    },

    actions: { add: true, edit: true, delete: true },

    add: {
      addButtonContent: '<i class="nb-plus"></i>',
      createButtonContent: '<i class="nb-checkmark"></i>',
      cancelButtonContent: '<i class="nb-close"></i>',
      confirmCreate: true,
      width: '40px',
      addMode: 'edit',
    },

    edit: {
      editButtonContent: '<i class="nb-edit"></i>',
      saveButtonContent: '<i class="nb-checkmark"></i>',
      cancelButtonContent: '<i class="nb-close"></i>',
      confirmSave: true,
      addMode: 'edit',
      mode: 'edit',
    },

    delete: {
      deleteButtonContent: '<i class="nb-trash"></i>',
      confirmDelete: true,
    },

    columns: {
      pessoa: {
        title: 'Pessoa',
        type: 'number',
        addable: false,
        filter: true,
        width: '90px',
      },

      nome: {
        title: 'Nome',
        type: 'string',
        filter: true,
        width: '250px',
      },

      cgcCpf: {
        title: 'CPF/CNPJ',
        type: 'number',
        filter: false,
        width: '250px',
      },

      dataNascimento: {
        title: 'Nome',
        type: 'string',
        filter: true,
        width: '520px',
      },

      
    },
  };

  constructor(
    private service: PesPessoaService,
    private toastrService: NbToastrService,
    private dialogService: NbDialogService,
  ) {}

  ngOnInit(): void {
    this.listar();

    this.source.onChanged().subscribe((change) => {
      if (change.action === 'filter') {
        this.onTableFilter(change.filter);
      }
    });
  }

  listar() {
    this.service.pesquisar(this.filtro)
      .then((response) => {
        const pesPessoa = response.pesPessoa ?? [];
        this.source.load(pesPessoa);
      })
      .catch((error) => console.error('Erro ao listar Pessoas de dbo_pessoas:', error));
  }

  onCreateConfirm(event) {
    console.log('oi')
  }

  onSaveConfirm(event) {
    console.log('oi')
  }

  onDeleteConfirm(event): void {
    console.log('oi')
  }

  onTableFilter(filters: any) {
    let params = new HttpParams();

    const filtersArray = (filters && filters.filters && Array.isArray(filters.filters)) ? filters.filters : [];
    const idFilter = filtersArray.find(f => f.field === 'id');
    const cidadeFilter = filtersArray.find(f => f.field === 'nomeCidade');
    const nomeFilter = filtersArray.find(f => f.field === 'nome');

    if (idFilter?.search) params = params.set('id', idFilter.search);
    if (cidadeFilter?.search) params = params.set('cidadeNome', cidadeFilter.search); // <<< agora filtra por cidade
    if (nomeFilter?.search) params = params.set('nome', nomeFilter.search);

    this.filtro.params = params;

    this.service.pesquisar({ ...this.filtro, params } as any)
      .then((response) => {
        const pesPessoas = response.pesPessoas ?? [];
        this.source.load(pesPessoas);
      });
  }
}