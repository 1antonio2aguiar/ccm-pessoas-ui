import { Injectable, Injector, EventEmitter } from '@angular/core';
import { Observable, from } from 'rxjs';
import { HttpClient, HttpParams } from '@angular/common/http';
import { map } from 'rxjs/operators';

import { environment } from '../../../../../environments/environment';
import { BaseResourceService } from '../../../../shared/services/base-resource.service';
import { FiltroPaginado } from '../../../../shared/filters/filtro-paginado';

import { PesPessoas } from '../../../../shared/models/unificacao/pes-pessoas';

@Injectable({ providedIn: 'root' })
export class PesPessoaService extends BaseResourceService<PesPessoas> {

  private pesPessoasEventHendlerId: EventEmitter<PesPessoas>;

  constructor(protected injector: Injector) {
    super(environment.apiUrl + 'pes-pessoas', injector, PesPessoas.fromJson);
    this.pesPessoasEventHendlerId = new EventEmitter<PesPessoas>();
  }

  pesquisar(filtro: FiltroPaginado): Promise<any> {
    let params = filtro.params;

    if (filtro.params) {
      filtro.params.keys().forEach(key => {
        params = params.set(key, filtro.params.get(key));
      });
    }

    return this.http
      .get<any>(this.apiPath + '/filter', { params })
      .toPromise()
      .then((response) => {
        const pesPessoas = Array.isArray(response) ? response : response?.content;
        console.log('Resultado ', pesPessoas)
        return { pesPessoas };
      });
  }

  
}
