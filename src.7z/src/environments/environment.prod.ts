/**
 * @license
 * Copyright Akveo. All Rights Reserved.
 * Licensed under the MIT License. See License.txt in the project root for license information.
 */

export const environment = {
  production: true,
  version: '1.0.0.0',
  apiUrl: 'localhost://8080/',
  //apiUrl: 'http://35.199.83.253:8080/',
  //apiUrlKripton: 'localhost://8080/',
  sistemaId: '1',

    

};