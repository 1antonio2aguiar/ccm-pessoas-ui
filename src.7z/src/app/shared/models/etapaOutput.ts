
export default interface EtapaOutput {

  id?: number,
  empresa?: number,
  nome?: string,
  campeonato?: number,
  localCompeticao?: number,
  dataEtapa?: string,
  dataInscricao?: string,
  pontua?: string,
  acumula?: string,
  tipoPiscina?: string,
  descricao?: string,

}

  