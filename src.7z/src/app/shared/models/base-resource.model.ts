export abstract class BaseResourceModel {
  id?: number;
}