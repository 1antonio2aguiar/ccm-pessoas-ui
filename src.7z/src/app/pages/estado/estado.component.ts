import { Component } from '@angular/core';

@Component({
  selector: 'ngx-estado',
  template: `<router-outlet></router-outlet>`,
})
export class EstadoComponent {}
