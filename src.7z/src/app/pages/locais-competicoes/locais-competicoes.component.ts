import { Component } from '@angular/core';

@Component({
  selector: 'ngx-locais-competicoes-iud',
  template: `<router-outlet></router-outlet>`,
})

export class LocaisCompeticoesComponent {

}
