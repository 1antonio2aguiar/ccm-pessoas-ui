import { Component } from '@angular/core';

@Component({
  selector: 'ngx-pais',
  template: `<router-outlet></router-outlet>`,
})

export class PaisComponent {}
