import { Injectable, Injector } from '@angular/core';
import { HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { environment } from '../../../../environments/environment';
import { BaseResourceService } from '../../../shared/services/base-resource.service';
import { Distrito } from '../../../shared/models/distrito';

@Injectable({ providedIn: 'root' })
export class DistritoService extends BaseResourceService<Distrito> {

  constructor(protected injector: Injector) {
    super(environment.apiUrl + 'distritos', injector, Distrito.fromJson);
  }

  /**
   * Autocomplete: usuário digita o NOME DA CIDADE,
   * e o backend retorna os distritos daquela cidade.
   *
   * Ex: /distritos/filter?cidadeNome=ubera
   */
  filtrarPorCidadeNome(cidadeNome: string, page = 0, size = 10): Observable<Distrito[]> {
    const params = new HttpParams()
      .set('cidadeNome', cidadeNome ?? '')
      .set('page', String(page))
      .set('size', String(size));

    return this.http
      .get<any>(`${this.apiPath}/filter`, { params })
      .pipe(
        map((resp) => {
          const lista = Array.isArray(resp) ? resp : (resp?.content ?? []);
          return (lista ?? [])
            .filter((x: any) => x && typeof x === 'object')
            .map((x: any) => Distrito.fromJson(x));
        }),
      );
  }
}