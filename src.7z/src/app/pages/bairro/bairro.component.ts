import { Component } from '@angular/core';

@Component({
  selector: 'ngx-bairro',
  template: `<router-outlet></router-outlet>`,
})
export class BairroComponent {}
