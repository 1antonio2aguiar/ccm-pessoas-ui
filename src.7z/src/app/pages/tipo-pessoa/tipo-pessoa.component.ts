import { Component } from '@angular/core';

@Component({
  selector: 'ngx-tipo-pessoa',
  template: `<router-outlet></router-outlet>`,
})
export class TipoPessoaComponent {}
