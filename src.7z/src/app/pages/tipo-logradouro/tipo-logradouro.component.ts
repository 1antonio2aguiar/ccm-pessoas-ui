import { Component } from '@angular/core';

@Component({
  selector: 'ngx-tipo-logradouro',
  template: `<router-outlet></router-outlet>`,
})
export class TipoLogradouroComponent {}
