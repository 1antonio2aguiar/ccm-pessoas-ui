import { Component } from '@angular/core';

@Component({
  selector: 'ngx-cidade',
  template: `<router-outlet></router-outlet>`,
})
export class CidadeComponent {}
