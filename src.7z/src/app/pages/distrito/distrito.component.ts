import { Component } from '@angular/core';

@Component({
  selector: 'ngx-distrito',
  template: `<router-outlet></router-outlet>`,
})
export class DistritoComponent {}
