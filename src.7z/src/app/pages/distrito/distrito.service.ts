import { Injectable, Injector, EventEmitter } from '@angular/core';
import { Observable, from } from 'rxjs';

import { environment } from '../../../environments/environment';
import { BaseResourceService } from '../../shared/services/base-resource.service';
import { FiltroPaginado } from '../../shared/filters/filtro-paginado';
import { Distrito } from '../../shared/models/distrito';

@Injectable({ providedIn: 'root' })
export class DistritoService extends BaseResourceService<Distrito> {

  private distritoEventHendlerId: EventEmitter<Distrito>;

  constructor(protected injector: Injector) {
    super(environment.apiUrl + 'distritos', injector, Distrito.fromJson);
    this.distritoEventHendlerId = new EventEmitter<Distrito>();
  }

  pesquisar(filtro: FiltroPaginado): Promise<any> {
    let params = filtro.params;

    if (filtro.params) {
      filtro.params.keys().forEach(key => {
        params = params.set(key, filtro.params.get(key));
      });
    }

    return this.http
      .get<any>(this.apiPath + '/filter', { params })
      .toPromise()
      .then((response) => {
        const distritos = Array.isArray(response) ? response : response?.content;
        return { distritos };
      });
  }

  create(distrito: Distrito): Observable<Distrito> {
    return this.http.post<Distrito>(this.apiPath, distrito);
  }

  update(distrito: Distrito): Observable<Distrito> {
    return from(this.http
      .put<Distrito>(`${this.apiPath}/${distrito.id}`, distrito)
      .toPromise()
      .then(response => response));
  }

  delete(id: number): Observable<any> {
    return from(this.http
      .delete<any>(`${this.apiPath}/${id}`)
      .toPromise()
      .then(response => response));
  }
}
