
export abstract class ModalidadeData {
  abstract getData(): any[];
}
